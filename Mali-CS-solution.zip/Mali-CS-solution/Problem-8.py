#Problem 8
#Python 3.3.4, development framework: IDLE, platform: Windows

#Directions:
#1. Run this file as a python(.py) file
#2. enter the integer number of matrices
#3. enter the list of dimentions, separated by commas and spaces
#4. after the optimal solution is calculated, Either continue to step 2 or press ENTER to quit

#TestCode (copied from console)

#number of matrices> 4
#comma separated dimentions> 5, 4, 2, 10, 3
#130 scalar multiplications (optimally)
#((A1*A2)*(A3*A4))

#number of matrices> 5
#comma separated dimentions> 30, 20, 10, 40, 5, 25
#9750 scalar multiplications (optimally)
#((A1*(A2*(A3*A4)))*A5)


#minimal matrix scalar multiplications, nonmemoization, bottom-up method

n=0
dim=[]
tree={}

order=[]

#the main function to calculate scalar multiplications
def m(i, j, dataQ=False):
    global tree
    global order
    global mlist
    
    if(dataQ==False):
        if(i==j):
            return 0
        else:
            
            vals=[]
            
            for k in range(i, j):
                val=tree[k-i+1][i] + tree[j-k][k+1]+dim[i-1]*dim[k]*dim[j]
                vals+=[val]
                
            sol = min(vals)
            
            return sol
    else:
        #backtracking the order of matrices
        if(i==j):
            return [i, j]
            
        vals=[]
        data={}
        for k in range(i, j):
            val=tree[k-i+1][i] + tree[j-k][k+1]+dim[i-1]*dim[k]*dim[j]
            vals+=[val]
            data.update({val:[i,k,j]})
        sol = min(vals)
        
        temp = data[sol]

        
        
        
        return [m(temp[0], temp[1], True), m(temp[1]+1, temp[2], True)]
        '''
        for e in order:
            if((e[0] <= temp[0]) & (temp[2] <= e[1])):
                idx = order.index(e)
                order.insert(idx, [[temp[0], temp[1]], [temp[1]+1, temp[2]]])
                order.remove(e)
        m(temp[0], temp[1], True)
        '''
        
    
            
#the main program loop
print("Press ENTER to quit anytime.")
while(1):
    n = input('number of matrices> ')
    if(n==''):
        break
    dim = input('comma separated dimentions> ')
    if(dim==''):
        break

    n=int(n)
    #user input done
    
    temp = str(dim)
    temp=temp.split(',')
    dim=[]
    for e in temp:
        dim.append(int(e.strip(' ')))
    del temp
    #formatting done

    
    #generare values

    for e in range(1,n+1):
        tree.update({e:{}})
        for i in range(1,n-e+1+1):
            tree[e].update({i:m(i,i+e-1)})
    print(str(m(1,n))+" scalar multiplications (optimally)")

    #print order, and format nicely
    
    order = m(1,n, True)
    order = str(order)
    for e in range(1,n+1):
        order = order.replace("["+str(e)+", "+str(e)+"]", "A"+str(e))
    order = order.replace("[", "(")
    order = order.replace("]", ")")
    
    order = order.replace(", ", "*")
    
    print(order)
    
    #reset for further uses
    order=[]
    dim=[]
    n=0
    tree={}
            

    
    
    

    
