#Problem 2
#Python 3.3.4, development framework: IDLE, platform: Windows

#Directions:
#1. Run this file as a python(.py) file
#2. enter a positive integer to computer the fibonacci sequence
#3. Either continue to step 2 or press ENTER to quit

#TEST CODE
#> 13
#233
#> 21
#10946


#dictionary of stored values
table={}


            
#fibonacci lookup, memoization
def fib(n):

    def lookup(n):
        global table
        if(n in table.keys()):
            return table[n]
        else:
            answer = fib(n)
            table.update({n:answer})
            return answer
    
    
    if(n==1):
        return 1
    elif(n==2):
        return 1

    
    elif((n>2) & (n%1==0)):
        Sum = 0
        Sum+=lookup(n-1)

        Sum+=lookup(n-2)
            
        return Sum
    else:
        return -1

print("Enter an integer n {n:n>0} to find fibonacci(n). Press ENTER to quit.")
while(1):
    n = input('> ')

    if(n==''):
        break

    answer = fib(int(n))
    if(answer == -1):
        print("Invalid input.")
        break
    else:
        print(answer)

    
