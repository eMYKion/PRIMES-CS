#Problem 3
#Python 3.3.4, development framework: IDLE, platform: Windows

#Directions:
#1. Run this file as a python(.py) file
#2. enter a positive integer to compute the fibonacci sequence
#3. Either continue to step 2 or press ENTER to quit

#TEST CODE
#> 23
#28657
#> 22
#17711
    
#fibonacci loop, nonmemoization, bottom-up method
def fib(n):
    #keep a "frame" of the largest 2 fibonacci numbers
    frame=[1,1]

    #define fib(1) = fib(2) = 1
    if((n==1) | (n==2)):
        return 1
    elif(n>2):
        largest=0
        for i in range(0,n-2):
            largest = sum(frame)
            frame[0] = frame [1]
            frame[1] = largest
        return largest
    else:
        return -1
        
        
#getting user input
print("Enter an integer n {n:n>0} to find fibonacci(n). Press ENTER to quit.")
while(1):
    n = input('> ')

    if(n==''):
        break

    answer = fib(int(n))
    if(answer == -1):
        print("Invalid input.")
        break
    else:
        print(answer)

    
