#Problem 1
#Python 3.3.4, development framework: IDLE, platform: Windows

#Directions:
#1. Run the code below
#2. enter a positive integer to computer the fibonacci sequence
#3. Either continue to step 2 or press ENTER to quit

#TEST CODE
#> 5
#5
#> 7
#13

def fibonacci(n):
    
    if(n==1):
        return 1
    elif(n==2):
        return 1
    elif((n>2) & (n%1==0)):
        return fibonacci(n-1) + fibonacci(n-2)
    else:
        return -1

print("Enter an integer n {n:n>0} to find fibonacci(n). Or press ENTER to quit.")
while(1):
    n = input("> ")
    
    if(n==''):
        break
    
    answer = fibonacci(int(n))
    
    if(answer==-1):
        print("invalid input")
    else:
        print(answer)
