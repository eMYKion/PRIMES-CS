#Problem 11
#Python 3.3.4, development framework: IDLE, platform: Windows

#Directions:
#1. Run this file as a python(.py) file
#2. enter the length of the string
#3. enter the sequence of break positions, separated by commas and spaces
#4. after the optimal solution is calculated and the order given, Either continue to step 2 or press ENTER to quit

#TestCode (copied from console)
#length of string> 20
#comma-separated break positions> 2, 8, 10
#38 is the most efficient cost
#10 8 2

#minimal string cutting, nonmemoization, bottom-up method

n = 0
breaks = []
tree={}
order=[]

def t(l,u,S, Qdata=False):
    global order
    data={}
    if(Qdata==False):
        remainingCuts=False
        for e in S:
            
            if(l<e<u):
                remainingCuts = True
        
        if(remainingCuts==False):#no cuts avaiable
            return 0
        else:
            
            vals=[]

            #since S is the total subset
            usedSubset = []
            for e in S:
                
                if(l<e<u):
                    usedSubset+=[e]
            
            for k in usedSubset:

                #to help with tree indexing
                spansU = 1
                spansL = 1
                for e in usedSubset:
                    if(l<e<k):
                        spansL+=1
                    if(k+1<e<u):
                        spansU+=1
                   
                val=tree[spansL][list(breaks+[20]).index(k)-spansL+1+1] + tree[spansU][list(breaks+[20]).index(u)-spansU+1+1] + u-l+1
                vals+=[val]
                data.update({val:k})
            
            sol = min(vals)
            order+=[data[sol]]
            #log the order
            return sol
    
            
            


            
print("Press ENTER to quit anytime.")
while(1):

    #getting user input
    n = input('length of string> ')
    if(n==''):
        break

    n = int(n)
    breaks = input('comma-separated break positions> ')
    if(breaks==''):
        break

    #format input into a list of ints
    breaks = breaks.split(',')
    temp = []
    for e in breaks:
        temp+=[int(e.strip(' '))]
    breaks = list(temp)
    del temp
    breaks = sorted(breaks) #order breaks for convenience
    
    nbreaks = len(breaks)
    
    #fills the tree bottom-up
    for e in range(1,nbreaks+1+1):#row
        tree.update({e:{}})
        for i in range(1,nbreaks-e+1+1+1):#column
            tree[e].update({i: t(list([0]+breaks)[i-1]+1, list(breaks+[n])[i-1+e-1] ,breaks)  })

    print(str(tree[nbreaks+1][1])+" is the most efficient cost")
    
        
    print(order[2], order[1], order[0])
        
    #reset for further uses
    n = 0
    breaks = []
    tree={}
    order=[]

    
            

    
    
    

    
